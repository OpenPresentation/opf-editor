import { mountJsonCodeEditor, type JsonCodeEditor } from '@openpresentation/opf-editor/json-editor';
import { getJsonFieldContext, replaceFieldOption, type JsonCatalogContext } from '@openpresentation/opf-editor/json-options';
const catalogs: JsonCatalogContext = {layouts:[{id:'partner',placeholders:[{type:'title'}]}]};
const control: JsonCodeEditor = mountJsonCodeEditor(document.createElement('div'), {code:'{"slides":[]}',label:'OPF JSON',catalogs,onChange(source){const context=getJsonFieldContext(source,0,catalogs);if(context)replaceFieldOption(context,context.options[0].value);}});
control.setCatalogs(catalogs);control.update(control.api.getValue());control.api.setSelection(...control.api.getSelection());control.destroy();
